let PRODUTOS = { sabores: [], bordas: [], bebidas: [], outros: [] };
let PRECOS_PIZZA = [];
let PROMOCOES = []; // promoções ativas: pizza de tamanho/sabores fixos e preço "de/por"
let CONFIG_LOJA = {};
let IMAGENS_TAMANHO = {}; // { 4: 'data:image/...', 6: ..., ... } - base64 vindo do banco
let CARRINHO = []; // itens acumulados: { tipo_item, pizza_categoria, fatias, sabor_ids, borda_id, quantidade, _nome, _preco }
// { categoriaAtiva, fatias, selecionados } - contexto da ficha de produto aberta.
// "categoriaAtiva" é só a aba visível no momento; "selecionados" é um Map
// sabor_id -> categoria com TODOS os sabores escolhidos, de qualquer aba,
// que é o que permite montar uma pizza com sabores de categorias diferentes
// (ex: 1 tradicional + 1 doce) sem perder a marcação ao trocar de aba.
let SABOR_ATUAL = null;
let CUPOM_APLICADO = null; // { codigo, tipo, valor, desconto } - null se nenhum cupom válido aplicado

// Seções do cardápio (Tradicional, Especial, Doce... ou as que o admin criar),
// já na ordem definida no painel: [{ id, nome, ordem }]
let SECOES = [];

document.addEventListener('DOMContentLoaded', async () => {
    aplicarIcones();
    await Promise.all([carregarSecoes(), carregarProdutos(), carregarPrecos(), carregarPromocoes(), carregarStatusLoja(), carregarImagensTamanho()]);
    renderizarCardapio();
    configurarEventos();
});

// Preenche todo <span class="icone" data-icone="NOME"> com o SVG de icones.js
function aplicarIcones() {
    document.querySelectorAll('[data-icone]').forEach(el => {
        el.innerHTML = ICONES[el.dataset.icone] || '';
    });
}

async function carregarImagensTamanho() {
    try {
        const imagens = await apiFetch('/imagens-tamanho');
        imagens.forEach(img => {
            if (img.imagem_base64) IMAGENS_TAMANHO[img.fatias] = img.imagem_base64;
        });
    } catch (err) {
        console.error('Erro ao carregar imagens de tamanho:', err.message);
    }
}

// Retorna o HTML pra mostrar no "quadrado" do card: a foto customizada do
// admin pra esse tamanho, se existir, senão o ícone SVG padrão de pizza.
// Já vem em base64 direto do banco - não depende de nenhum arquivo em disco,
// que era o motivo da foto sumir quando o servidor reiniciava.
function iconeOuImagemTamanho(fatias) {
    if (IMAGENS_TAMANHO[fatias]) {
        return `<img src="${IMAGENS_TAMANHO[fatias]}" alt="${fatias} fatias" class="imagem-categoria-card">`;
    }
    return `<span class="icone">${ICONES.pizza}</span>`;
}

// Mesma ideia, mas pra bebidas e outros - cada produto pode ter a própria
// foto cadastrada no admin.
function iconeOuImagemProduto(produto, iconeFallback) {
    if (produto.imagem_base64) {
        return `<img src="${produto.imagem_base64}" alt="${produto.nome}" class="imagem-categoria-card">`;
    }
    return `<span class="icone">${iconeFallback}</span>`;
}

async function carregarProdutos() {
    try {
        const produtos = await apiFetch('/produtos?disponiveis=true');
        PRODUTOS.sabores = produtos.filter(p => p.tipo === 'sabor_pizza');
        PRODUTOS.bordas = produtos.filter(p => p.tipo === 'borda');
        PRODUTOS.bebidas = produtos.filter(p => p.tipo === 'bebida');
        PRODUTOS.outros = produtos.filter(p => p.tipo === 'outros');
    } catch (err) {
        document.getElementById('secoes-cardapio').innerHTML =
            `<p class="erro">Não foi possível carregar o cardápio. Verifique se o servidor está rodando.</p>`;
    }
}

async function carregarSecoes() {
    try {
        SECOES = await apiFetch('/secoes-cardapio');
    } catch (err) {
        console.error('Erro ao carregar seções:', err.message);
    }
}

function nomeDaSecao(secaoId) {
    const secao = SECOES.find(s => s.id === secaoId);
    return secao ? secao.nome : '';
}

async function carregarPrecos() {
    try {
        PRECOS_PIZZA = await apiFetch('/precos-pizza');
    } catch (err) {
        console.error(err);
    }
}

async function carregarPromocoes() {
    try {
        PROMOCOES = await apiFetch('/promocoes');
    } catch (err) {
        console.error('Erro ao carregar promoções:', err.message);
    }
}

async function carregarStatusLoja() {
    const faixa = document.getElementById('faixa-status');
    try {
        const config = await apiFetch('/config');
        CONFIG_LOJA = config;
        preencherRodape(config); 
        const agora = new Date();
        const horaAtual = agora.toLocaleTimeString('pt-BR', { timeZone: 'America/Sao_Paulo', hour12: false });
        // Mesmo ajuste do backend: quando o fechamento passa da meia-noite
        // (ex: abre 17:30, fecha 01:00), a comparação simples "entre
        // abertura e fechamento" não funciona, porque 01:00 é "menor" que
        // 17:30. Nesse caso a loja está aberta se a hora atual for >= abertura
        // OU <= fechamento.
        const cruzaMeiaNoite = config.horario_fechamento < config.horario_abertura;
        const aberto = cruzaMeiaNoite
            ? (horaAtual >= config.horario_abertura || horaAtual <= config.horario_fechamento)
            : (horaAtual >= config.horario_abertura && horaAtual <= config.horario_fechamento);

        if (aberto) {
            faixa.textContent = `Loja aberta · Fecha às ${config.horario_fechamento?.slice(0, 5)}`;
            faixa.classList.add('aberta');
        } else {
            faixa.textContent = `Loja fechada · Abre hoje às ${config.horario_abertura?.slice(0, 5)}`;
            faixa.classList.remove('aberta');
        }

        renderizarFaixaPromocao(config);
    } catch (err) {
        faixa.style.display = 'none';
    }
}

// Banner fixo de promoção, configurado pelo admin - só um aviso, não aplica
// desconto sozinho (desconto de verdade é via cupom).
function renderizarFaixaPromocao(config) {
    const faixa = document.getElementById('faixa-promocao');
    if (config.promocao_ativa && config.promocao_texto) {
        faixa.textContent = `📣 ${config.promocao_texto}`;
        faixa.classList.remove('oculto');
    } else {
        faixa.classList.add('oculto');
    }
}

function obterPreco(secaoId, fatias) {
    const item = PRECOS_PIZZA.find(p => p.secao_id === secaoId && Number(p.fatias) === Number(fatias));
    return item ? Number(item.preco) : null;
}

// ---------- Renderização do cardápio ----------
// Layout: uma única seção de "Tamanhos" (lista vertical, de cima pra baixo),
// sem separar por categoria - a categoria (Tradicional/Especial/Doce/Promoção)
// só é escolhida dentro da ficha do produto, não na tela inicial.
// Bebidas e Outros sempre no final da página.
const FATIAS_OPCOES = [4, 6, 8, 12, 14];

function categoriasComSabores() {
    return SECOES.map(sec => sec.id).filter(id => PRODUTOS.sabores.some(s => s.secao_id === id));
}

// Categoria usada como ponto de partida ao abrir a ficha do produto.
function categoriaPadrao() {
    return categoriasComSabores()[0] ?? null;
}

function renderizarCardapio() {
    const main = document.getElementById('secoes-cardapio');
    main.innerHTML = `
        <section class="secao-categoria" id="secao-promocoes">
            <h2><span class="icone icone-titulo-secao">${ICONES.fogo}</span> Promoções</h2>
            <p class="dica-passo">👉 Clique aqui e escolha uma promoção - os sabores já vêm limitados aos dessa promoção</p>
            <div class="lista-linhas" id="lista-promocoes"></div>
        </section>
        <section class="secao-categoria" id="secao-tamanhos">
            <h2><span class="icone icone-titulo-secao">${ICONES.pizza}</span> Tamanhos</h2>
            <p class="dica-passo">👉 Clique aqui e escolha o tamanho da sua pizza</p>
            <div class="lista-linhas" id="lista-tamanhos"></div>
        </section>
        <section class="secao-categoria" id="secao-bebidas">
            <h2><span class="icone icone-titulo-secao">${ICONES.bebida}</span> Bebidas</h2>
            <p class="dica-passo">👉 Clique aqui e escolha uma bebida para adicionar ao carrinho</p>
            <div class="lista-linhas" id="lista-bebidas"></div>
        </section>
        <section class="secao-categoria" id="secao-outros">
            <h2><span class="icone icone-titulo-secao">${ICONES.ferramentas}</span> Outros</h2>
            <p class="dica-passo">👉 Clique aqui e escolha um item extra para adicionar ao carrinho</p>
            <div class="lista-linhas" id="lista-outros"></div>
        </section>
    `;

    renderizarPromocoesCliente();
    renderizarTamanhos();
    renderizarBebidas();
    renderizarOutros();
}

// Promoções: pizza de tamanho e sabores fixos, definida pelo admin, com
// preço fixo "de/por" (não usa a tabela de preços por categoria). Some da
// tela se não houver nenhuma promoção ativa.
function renderizarPromocoesCliente() {
    const secao = document.getElementById('secao-promocoes');
    if (!PROMOCOES || PROMOCOES.length === 0) { secao.remove(); return; }

    const lista = document.getElementById('lista-promocoes');
    lista.innerHTML = PROMOCOES.map(promo => {
        const nomesSabores = promo.sabor_ids
            .map(id => PRODUTOS.sabores.find(s => s.id === id)?.nome)
            .filter(Boolean)
            .join(', ');
        return `
            <button class="linha-produto" data-promocao-id="${promo.id}">
                <div class="linha-produto-imagem">${iconeOuImagemTamanho(promo.fatias)}</div>
                <div class="linha-produto-info">
                    <div class="linha-produto-nome">${escapeHtml(promo.nome)} (${promo.fatias} fatias)</div>
                    <div class="linha-produto-desc">${escapeHtml(nomesSabores)}</div>
                </div>
                <span class="card-preco card-preco-promo">
                    <s>R$ ${Number(promo.preco_de).toFixed(2)}</s>
                    R$ ${Number(promo.preco_por).toFixed(2)}
                </span>
                <span class="seta-linha" aria-hidden="true">›</span>
            </button>
        `;
    }).join('');

    lista.querySelectorAll('.linha-produto[data-promocao-id]').forEach(linha => {
        linha.addEventListener('click', () => abrirFichaPromocao(Number(linha.dataset.promocaoId)));
    });
}

// Seção única de tamanhos: lista vertical, sem escolher categoria ainda.
// O preço mostrado é "a partir de" (o menor entre as categorias com sabor
// cadastrado pra aquele tamanho) - a categoria exata é escolhida na ficha.
function renderizarTamanhos() {
    const lista = document.getElementById('lista-tamanhos');
    const categorias = categoriasComSabores();

    if (categorias.length === 0) {
        lista.innerHTML = '<p class="carregando">Nenhum sabor cadastrado ainda.</p>';
        return;
    }

    const linhas = FATIAS_OPCOES.map(fatias => {
        const precos = categorias.map(cat => obterPreco(cat, fatias)).filter(p => p !== null);
        if (precos.length === 0) return '';
        const menorPreco = Math.min(...precos);
        return `
            <button class="linha-produto" data-fatias="${fatias}">
                <div class="linha-produto-imagem">${iconeOuImagemTamanho(fatias)}</div>
                <div class="linha-produto-info">
                    <div class="linha-produto-nome">${fatias} fatias</div>
                    <div class="linha-produto-desc">Escolha o tipo e os sabores</div>
                </div>
                <span class="card-preco">a partir de R$ ${menorPreco.toFixed(2)}</span>
                <span class="seta-linha" aria-hidden="true">›</span>
            </button>
        `;
    }).join('');

    lista.innerHTML = linhas.trim() || '<p class="carregando">Preços não configurados ainda.</p>';

    lista.querySelectorAll('.linha-produto[data-fatias]').forEach(linha => {
        linha.addEventListener('click', () => abrirFichaProduto(Number(linha.dataset.fatias)));
    });
}

function renderizarBebidas() {
    const secao = document.getElementById('secao-bebidas');
    if (PRODUTOS.bebidas.length === 0) { secao.remove(); return; }

    const lista = document.getElementById('lista-bebidas');
    lista.innerHTML = PRODUTOS.bebidas.map(b => `
        <div class="linha-produto linha-produto-simples linha-produto-clicavel" data-bebida-id="${b.id}" role="button" tabindex="0">
            <div class="linha-produto-imagem">${iconeOuImagemProduto(b, ICONES.bebida)}</div>
            <div class="linha-produto-info"><div class="linha-produto-nome">${b.nome}</div></div>
            <span class="card-preco">R$ ${Number(b.preco_base).toFixed(2)}</span>
            <span class="badge-qtd-rapida oculto" data-badge-bebida="${b.id}"></span>
            <span class="icone icone-add-rapido">${ICONES.mais}</span>
        </div>
    `).join('');

    lista.querySelectorAll('.linha-produto-clicavel').forEach(card => {
        card.addEventListener('click', () => adicionarBebidaRapida(Number(card.dataset.bebidaId), card));
        card.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); adicionarBebidaRapida(Number(card.dataset.bebidaId), card); }
        });
    });
    atualizarBadgesRapidos();
}

// "Outros" - itens do cardápio que não são pizza, borda nem bebida
// (ex: sobremesas avulsas, molhos extras). Sempre por último na página.
function renderizarOutros() {
    const secao = document.getElementById('secao-outros');
    if (!PRODUTOS.outros || PRODUTOS.outros.length === 0) { secao.remove(); return; }

    const lista = document.getElementById('lista-outros');
    lista.innerHTML = PRODUTOS.outros.map(o => `
        <div class="linha-produto linha-produto-simples linha-produto-clicavel" data-outro-id="${o.id}" role="button" tabindex="0">
            <div class="linha-produto-imagem">${iconeOuImagemProduto(o, ICONES.ferramentas)}</div>
            <div class="linha-produto-info">
                <div class="linha-produto-nome">${o.nome}</div>
                ${o.descricao ? `<div class="linha-produto-desc">${escapeHtml(o.descricao)}</div>` : ''}
            </div>
            <span class="card-preco">R$ ${Number(o.preco_base).toFixed(2)}</span>
            <span class="badge-qtd-rapida oculto" data-badge-outro="${o.id}"></span>
            <span class="icone icone-add-rapido">${ICONES.mais}</span>
        </div>
    `).join('');

    lista.querySelectorAll('.linha-produto-clicavel').forEach(card => {
        card.addEventListener('click', () => adicionarOutroRapido(Number(card.dataset.outroId), card));
        card.addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); adicionarOutroRapido(Number(card.dataset.outroId), card); }
        });
    });
    atualizarBadgesRapidos();
}

// Mostra, em cada card de bebida/outro, quantas unidades já estão no
// carrinho agora - assim dá pra ver o efeito do clique sem abrir o carrinho.
function atualizarBadgesRapidos() {
    document.querySelectorAll('[data-badge-bebida]').forEach(badge => {
        const item = CARRINHO.find(i => i.tipo_item === 'bebida' && i.produto_id === Number(badge.dataset.badgeBebida));
        badge.textContent = item ? item.quantidade : '';
        badge.classList.toggle('oculto', !item);
    });
    document.querySelectorAll('[data-badge-outro]').forEach(badge => {
        const item = CARRINHO.find(i => i.tipo_item === 'outros' && i.produto_id === Number(badge.dataset.badgeOutro));
        badge.textContent = item ? item.quantidade : '';
        badge.classList.toggle('oculto', !item);
    });
}

// ---------- Ficha do produto (sheet) ----------
// A categoria (Tradicional/Especial/Doce/Promoção) é escolhida aqui dentro,
// através das abas, não mais na tela inicial - só o tamanho vem de fora.
function abrirFichaProduto(fatias) {
    SABOR_ATUAL = { categoriaAtiva: categoriaPadrao(), fatias, selecionados: new Map(), promocao: null };

    document.getElementById('qtd-valor').textContent = '1';
    renderizarAbasCategoriaSheet();
    renderizarConteudoSheet();

    const selectBorda = document.getElementById('sheet-borda');
    selectBorda.innerHTML = '<option value="">Sem borda</option>' + PRODUTOS.bordas.map(b =>
        `<option value="${b.id}" data-preco="${b.preco_base}">${b.nome} (+R$ ${Number(b.preco_base).toFixed(2)})</option>`
    ).join('');

    document.getElementById('sheet-fundo-produto').classList.remove('oculto');
}

// Ficha de uma promoção: mesma janela da pizza normal, mas sem abas de
// categoria - os sabores mostrados já vêm limitados aos que o admin marcou
// nessa promoção, e o preço é sempre o fixo "de/por", não o da tabela normal.
function abrirFichaPromocao(promocaoId) {
    const promocao = PROMOCOES.find(p => p.id === promocaoId);
    if (!promocao) return;

    SABOR_ATUAL = { categoriaAtiva: null, fatias: promocao.fatias, selecionados: new Map(), promocao };

    document.getElementById('qtd-valor').textContent = '1';
    document.getElementById('sheet-categorias').innerHTML = '';
    renderizarConteudoSheet();

    const selectBorda = document.getElementById('sheet-borda');
    selectBorda.innerHTML = '<option value="">Sem borda</option>' + PRODUTOS.bordas.map(b =>
        `<option value="${b.id}" data-preco="${b.preco_base}">${b.nome} (+R$ ${Number(b.preco_base).toFixed(2)})</option>`
    ).join('');

    document.getElementById('sheet-fundo-produto').classList.remove('oculto');
}

// Abas de categoria dentro da ficha - só mostra categorias com sabor cadastrado.
// Trocar de aba só muda o que fica visível pra marcar; os sabores já
// escolhidos em outras abas continuam guardados em SABOR_ATUAL.selecionados,
// então dá pra combinar sabores de categorias diferentes na mesma pizza.
function renderizarAbasCategoriaSheet() {
    const container = document.getElementById('sheet-categorias');
    const categorias = categoriasComSabores();

    container.innerHTML = categorias.map(cat => {
        const qtdNaAba = [...SABOR_ATUAL.selecionados.values()].filter(c => c === cat).length;
        return `
        <button type="button" class="pill-categoria-sheet${cat === SABOR_ATUAL.categoriaAtiva ? ' ativo' : ''}" data-categoria="${cat}">
            ${escapeHtml(nomeDaSecao(cat))}${qtdNaAba > 0 ? ` <span class="badge-contagem-sabor">${qtdNaAba}</span>` : ''}
        </button>
    `;
    }).join('');

    container.querySelectorAll('.pill-categoria-sheet').forEach(pill => {
        pill.addEventListener('click', () => {
            const secaoClicada = Number(pill.dataset.categoria);
            if (secaoClicada === SABOR_ATUAL.categoriaAtiva) return;
            SABOR_ATUAL.categoriaAtiva = secaoClicada;
            renderizarAbasCategoriaSheet();
            renderizarConteudoSheet();
        });
    });
}

// Imagem, título, preço e lista de sabores - depende da categoria escolhida
// nas abas acima, então é chamada de novo toda vez que ela muda.
function renderizarConteudoSheet() {
    const { categoriaAtiva, fatias, selecionados, promocao } = SABOR_ATUAL;

    document.getElementById('sheet-imagem').innerHTML = iconeOuImagemTamanho(fatias);
    document.getElementById('sheet-titulo').textContent = promocao
        ? `${promocao.nome} - ${fatias} fatias`
        : `Pizza - ${fatias} fatias`;
    atualizarPrecoSheet();

    // Em promoção, a lista de sabores já vem limitada aos que o admin
    // marcou ao criar a promoção (podem ser de categorias diferentes).
    const sabores = promocao
        ? promocao.sabor_ids.map(id => PRODUTOS.sabores.find(s => s.id === id)).filter(Boolean)
        : PRODUTOS.sabores.filter(s => s.secao_id === categoriaAtiva);

    const container = document.getElementById('sheet-sabores-extra');
    container.innerHTML = sabores.map(s => `
        <label class="opcao-sabor">
            <input type="checkbox" name="sheet-sabor" value="${s.id}" ${selecionados.has(s.id) ? 'checked' : ''}>
            <span>
                <strong>${s.nome}</strong>
                ${s.descricao ? `<br><small>${s.descricao}</small>` : ''}
            </span>
        </label>
    `).join('');

    container.onchange = (event) => {
        const id = Number(event.target.value);
        if (event.target.checked) {
            if (selecionados.size >= 3) {
                event.target.checked = false;
                alert('Máximo de 3 sabores por pizza, no total (pode ser de categorias diferentes).');
                return;
            }
            const sabor = sabores.find(s => s.id === id);
            selecionados.set(id, sabor ? sabor.secao_id : categoriaAtiva);
        } else {
            selecionados.delete(id);
        }
        if (!promocao) renderizarAbasCategoriaSheet();
        atualizarPrecoSheet();
    };
}

// Preço da pizza = preço da categoria mais cara entre as dos sabores já
// escolhidos (regra pra combinações mistas). Enquanto nada foi marcado ainda,
// mostra o preço "a partir de" da aba aberta no momento, só como prévia.
function atualizarPrecoSheet() {
    const { categoriaAtiva, fatias, selecionados, promocao } = SABOR_ATUAL;
    const el = document.getElementById('sheet-preco');

    if (promocao) {
        el.innerHTML = `<span class="etiqueta-preco-promo"><s>R$ ${Number(promocao.preco_de).toFixed(2)}</s> R$ ${Number(promocao.preco_por).toFixed(2)}</span>`;
        return;
    }

    if (selecionados.size === 0) {
        const preco = obterPreco(categoriaAtiva, fatias);
        el.innerHTML = preco !== null
            ? `<span class="etiqueta-preco">a partir de R$ ${preco.toFixed(2)}</span>`
            : '<span class="erro">Preço não configurado.</span>';
        return;
    }

    const categoriasEnvolvidas = [...new Set(selecionados.values())];
    const precos = categoriasEnvolvidas.map(cat => obterPreco(cat, fatias));
    if (precos.some(p => p === null)) {
        el.innerHTML = '<span class="erro">Preço não configurado.</span>';
        return;
    }
    const maiorPreco = Math.max(...precos);
    const misturouCategorias = categoriasEnvolvidas.length > 1;
    el.innerHTML = `<span class="etiqueta-preco">R$ ${maiorPreco.toFixed(2)}</span>` +
        (misturouCategorias ? ' <small class="aviso-preco-misto">(preço da categoria mais cara)</small>' : '');
}

function fecharFichaProduto() {
    document.getElementById('sheet-fundo-produto').classList.add('oculto');
    SABOR_ATUAL = null;
}

function adicionarAoCarrinho() {
    const { fatias, selecionados, promocao } = SABOR_ATUAL;

    const saborIds = [...selecionados.keys()];
    if (saborIds.length === 0) return alert('Escolha ao menos 1 sabor.');

    const bordaSelect = document.getElementById('sheet-borda');
    const bordaId = bordaSelect.value ? Number(bordaSelect.value) : null;
    const precoBorda = bordaId ? Number(bordaSelect.selectedOptions[0].dataset.preco) : 0;
    const nomeBorda = bordaId ? bordaSelect.selectedOptions[0].textContent : null;
    const quantidade = Number(document.getElementById('qtd-valor').textContent);
    const nomesSabores = saborIds.map(id => PRODUTOS.sabores.find(s => s.id === id)?.nome).join(', ');

    // Pizza de promoção: preço fixo "de/por" definido pelo admin, não usa
    // a tabela de preços por categoria (o servidor confere tudo de novo).
    if (promocao) {
        CARRINHO.push({
            tipo_item: 'pizza',
            pizza_categoria: null,
            promocao_id: promocao.id,
            fatias,
            sabor_ids: saborIds,
            borda_id: bordaId,
            quantidade,
            _nome: `${promocao.nome} (${fatias} fatias) - ${nomesSabores}${nomeBorda ? ' + ' + nomeBorda : ''}`,
            _preco: Number(promocao.preco_por) + precoBorda
        });

        fecharFichaProduto();
        atualizarBarraCarrinho();
        return;
    }

    // Categoria de cobrança: a mais cara entre as dos sabores escolhidos.
    // O servidor recalcula isso de novo a partir do banco na hora de confirmar
    // o pedido - aqui é só pra mostrar preço e nome certos no carrinho.
    const categoriasEnvolvidas = [...new Set(selecionados.values())];
    const precosPorCategoria = categoriasEnvolvidas.map(cat => ({ cat, preco: obterPreco(cat, fatias) }));
    if (precosPorCategoria.some(p => p.preco === null)) {
        return alert('Preço não configurado para essa combinação.');
    }
    const categoriaCobranca = precosPorCategoria.reduce((maior, atual) => atual.preco > maior.preco ? atual : maior).cat;
    const precoPizza = precosPorCategoria.reduce((maior, atual) => atual.preco > maior.preco ? atual : maior).preco;

    CARRINHO.push({
        tipo_item: 'pizza',
        pizza_categoria: nomeDaSecao(categoriaCobranca),
        fatias,
        sabor_ids: saborIds,
        borda_id: bordaId,
        quantidade,
        _nome: `Pizza (${fatias} fatias) - ${nomesSabores}${nomeBorda ? ' + ' + nomeBorda : ''}`,
        _preco: precoPizza + precoBorda
    });

    fecharFichaProduto();
    atualizarBarraCarrinho();
}

function adicionarBebidaRapida(produtoId, cardEl) {
    const bebida = PRODUTOS.bebidas.find(b => b.id === produtoId);
    const existente = CARRINHO.find(i => i.tipo_item === 'bebida' && i.produto_id === produtoId);
    if (existente) {
        existente.quantidade += 1;
    } else {
        CARRINHO.push({
            tipo_item: 'bebida',
            produto_id: produtoId,
            quantidade: 1,
            _nome: bebida.nome,
            _preco: Number(bebida.preco_base)
        });
    }
    atualizarBarraCarrinho();
    atualizarBadgesRapidos();
    if (cardEl) piscarFeedbackAdicionado(cardEl);
}

function adicionarOutroRapido(produtoId, cardEl) {
    const produto = PRODUTOS.outros.find(o => o.id === produtoId);
    const existente = CARRINHO.find(i => i.tipo_item === 'outros' && i.produto_id === produtoId);
    if (existente) {
        existente.quantidade += 1;
    } else {
        CARRINHO.push({
            tipo_item: 'outros',
            produto_id: produtoId,
            quantidade: 1,
            _nome: produto.nome,
            _preco: Number(produto.preco_base)
        });
    }
    atualizarBarraCarrinho();
    atualizarBadgesRapidos();
    if (cardEl) piscarFeedbackAdicionado(cardEl);
}

// Pisca o card rapidinho ao adicionar - é o único feedback que a pessoa tem
// agora que o clique é no card inteiro (não tem mais botão "+" separado).
function piscarFeedbackAdicionado(cardEl) {
    cardEl.classList.remove('card-adicionado');
    // força reiniciar a animação mesmo em cliques rápidos e seguidos
    void cardEl.offsetWidth;
    cardEl.classList.add('card-adicionado');
}

function removerDoCarrinho(index) {
    CARRINHO.splice(index, 1);
    atualizarBarraCarrinho();
    renderizarCarrinho();
    atualizarBadgesRapidos();
}

// Usado pelo +/- de cada linha do carrinho. Chegando a 0, remove a linha -
// assim a pessoa ajusta a quantidade sem precisar remover tudo e adicionar
// de novo do zero.
function alterarQuantidadeCarrinho(index, delta) {
    const item = CARRINHO[index];
    if (!item) return;
    item.quantidade += delta;
    if (item.quantidade <= 0) {
        CARRINHO.splice(index, 1);
    }
    atualizarBarraCarrinho();
    renderizarCarrinho();
    atualizarBadgesRapidos();
}

function calcularTaxaEntrega() {
    const tipoEntrega = document.getElementById('tipo-entrega').value;
    return tipoEntrega === 'entrega' ? Number(CONFIG_LOJA.taxa_entrega || 0) : 0;
}

function calcularSubtotalCarrinho() {
    return CARRINHO.reduce((soma, item) => soma + item._preco * item.quantidade, 0);
}

// Recalculado a partir do subtotal atual (não guarda um valor fixo), pra
// ficar certo mesmo se o cliente mudar o carrinho depois de aplicar o cupom.
function calcularDesconto() {
    if (!CUPOM_APLICADO) return 0;
    const subtotal = calcularSubtotalCarrinho();
    const desconto = CUPOM_APLICADO.tipo === 'percentual'
        ? subtotal * (CUPOM_APLICADO.valor / 100)
        : CUPOM_APLICADO.valor;
    return Math.min(desconto, subtotal);
}

function calcularTotalCarrinho() {
    const total = calcularSubtotalCarrinho() + calcularTaxaEntrega() - calcularDesconto();
    return Math.max(0, total);
}

function atualizarBarraCarrinho() {
    const barra = document.getElementById('barra-carrinho');
    const totalItens = CARRINHO.reduce((s, i) => s + i.quantidade, 0);

    if (totalItens === 0) {
        barra.classList.add('oculto');
        return;
    }
    barra.classList.remove('oculto');
    document.getElementById('carrinho-resumo').textContent =
        `${totalItens} ${totalItens === 1 ? 'item' : 'itens'} · R$ ${calcularTotalCarrinho().toFixed(2)}`;
}

// ---------- Carrinho / checkout ----------
function abrirCarrinho() {
    renderizarCarrinho();
    controlarInfoPix(document.getElementById('forma-pagamento').value);
    document.getElementById('sheet-fundo-carrinho').classList.remove('oculto');
}

function fecharCarrinho() {
    document.getElementById('sheet-fundo-carrinho').classList.add('oculto');
}

function renderizarCarrinho() {
    const container = document.getElementById('itens-carrinho');
    if (CARRINHO.length === 0) {
        container.innerHTML = '<p class="carregando">Carrinho vazio.</p>';
    } else {
        container.innerHTML = CARRINHO.map((item, i) => `
            <div class="linha-item-carrinho">
                <div class="linha-item-info">
                    <strong>${escapeHtml(item._nome)}</strong>
                    <div class="preco-item">R$ ${(item._preco * item.quantidade).toFixed(2)}</div>
                </div>
                <div class="stepper-carrinho">
                    <button type="button" class="btn-qtd" onclick="alterarQuantidadeCarrinho(${i}, -1)" aria-label="Diminuir quantidade">−</button>
                    <span>${item.quantidade}</span>
                    <button type="button" class="btn-qtd" onclick="alterarQuantidadeCarrinho(${i}, 1)" aria-label="Aumentar quantidade">+</button>
                </div>
                <button type="button" class="btn-remover-item" onclick="removerDoCarrinho(${i})" aria-label="Remover item"><span class="icone">${ICONES.lixeira}</span></button>
            </div>
        `).join('');
    }

    const taxa = calcularTaxaEntrega();
    const linhaTaxa = document.getElementById('linha-taxa-entrega');
    if (taxa > 0) {
        linhaTaxa.classList.remove('oculto');
        document.getElementById('valor-taxa-entrega').textContent = `R$ ${taxa.toFixed(2)}`;
    } else {
        linhaTaxa.classList.add('oculto');
    }

    const desconto = calcularDesconto();
    const linhaDesconto = document.getElementById('linha-desconto');
    if (CUPOM_APLICADO && desconto > 0) {
        linhaDesconto.classList.remove('oculto');
        document.getElementById('codigo-cupom-aplicado').textContent = CUPOM_APLICADO.codigo;
        document.getElementById('valor-desconto').textContent = `-R$ ${desconto.toFixed(2)}`;
    } else {
        linhaDesconto.classList.add('oculto');
    }

    document.getElementById('carrinho-total').textContent = `R$ ${calcularTotalCarrinho().toFixed(2)}`;
}

// Confere o cupom com o servidor e, se válido, guarda em CUPOM_APLICADO pra
// entrar no cálculo do total. O desconto de verdade é revalidado de novo no
// servidor quando o pedido é confirmado - isso aqui é só a prévia pro cliente.
async function aplicarCupom() {
    const input = document.getElementById('input-cupom');
    const codigo = input.value.trim();
    const msg = document.getElementById('mensagem-cupom');

    if (!codigo) return;

    if (CARRINHO.length === 0) {
        return exibirMensagemCupom('Adicione itens ao carrinho antes de aplicar um cupom.', false);
    }

    try {
        const resultado = await apiFetch('/cupons/validar', {
            method: 'POST',
            body: JSON.stringify({ codigo, subtotal: calcularSubtotalCarrinho() })
        });
        CUPOM_APLICADO = resultado;
        exibirMensagemCupom(`Cupom ${resultado.codigo} aplicado! -R$ ${resultado.desconto.toFixed(2)}`, true);
    } catch (err) {
        CUPOM_APLICADO = null;
        exibirMensagemCupom(err.message, false);
    }

    renderizarCarrinho();
    atualizarBarraCarrinho();
}

function exibirMensagemCupom(texto, sucesso) {
    const msg = document.getElementById('mensagem-cupom');
    msg.textContent = texto;
    msg.classList.remove('oculto', 'mensagem-cupom-sucesso', 'mensagem-cupom-erro');
    msg.classList.add(sucesso ? 'mensagem-cupom-sucesso' : 'mensagem-cupom-erro');
}

function controlarCamposEntrega(valor) {
    document.getElementById('campos-entrega').classList.toggle('oculto', valor !== 'entrega');
    renderizarCarrinho(); // a taxa de entrega muda o total, precisa recalcular na hora
}

// Ao terminar de digitar o telefone, busca se esse número já fez pedido
// antes e pré-preenche nome/endereço - só quando esses campos ainda
// estiverem vazios, pra nunca sobrescrever algo que o cliente já digitou
// na mão. Silenciosamente não faz nada se não achar (telefone novo é o
// caso mais comum, não é um erro).
async function buscarDadosClienteSalvos() {
    const campoTelefone = document.getElementById('telefone');
    const digitos = campoTelefone.value.replace(/\D/g, '');
    const mensagem = document.getElementById('mensagem-cliente-reconhecido');
    mensagem.classList.add('oculto');

    if (digitos.length < 10) return; // telefone ainda incompleto

    try {
        const dados = await apiFetch(`/pedidos/cliente/${digitos}`);

        const campoNome = document.getElementById('nome');
        const campoEndereco = document.getElementById('endereco');
        if (!campoNome.value.trim()) campoNome.value = dados.cliente_nome;
        if (!campoEndereco.value.trim()) campoEndereco.value = dados.endereco || '';

        const primeiroNome = dados.cliente_nome.split(' ')[0];
        mensagem.textContent = `Bem-vindo(a) de volta, ${primeiroNome}! Preenchemos seus dados do último pedido.`;
        mensagem.classList.remove('oculto');
    } catch (err) {
        // 404 (telefone novo, sem pedido anterior) é o caso normal - não avisa nada.
        // Erros de rede/limite também ficam quietos aqui: é só uma comodidade,
        // não deve travar o cliente terminando de preencher o pedido na mão.
    }
}

function controlarTroco(valor) {
    document.getElementById('campo-troco').classList.toggle('oculto', valor !== 'dinheiro');
}

// Mostra a chave Pix + aviso quando o cliente escolhe pagar por Pix
function controlarInfoPix(valor) {
    const caixa = document.getElementById('info-pix');
    if (valor === 'pix') {
        document.getElementById('texto-chave-pix').textContent = CONFIG_LOJA.chave_pix || 'Chave não configurada - fale com a pizzaria';
        caixa.classList.remove('oculto');
    } else {
        caixa.classList.add('oculto');
    }
}

async function confirmarPedido() {
    const aviso = document.getElementById('aviso-carrinho');
    aviso.classList.add('oculto');

    const nome = document.getElementById('nome').value.trim();
    const tipoEntrega = document.getElementById('tipo-entrega').value;
    const telefone = document.getElementById('telefone').value.trim();
    const endereco = document.getElementById('endereco').value.trim();
    const observacoes = document.getElementById('observacoes').value.trim();
    const formaPagamento = document.getElementById('forma-pagamento').value;
    const troco = document.getElementById('troco').value;

    if (CARRINHO.length === 0) return mostrarAvisoCarrinho('Seu carrinho está vazio.');
    if (!nome) return mostrarAvisoCarrinho('Digite seu nome.');
    if (tipoEntrega === 'entrega' && (!telefone || !endereco)) {
        return mostrarAvisoCarrinho('Telefone e endereço são obrigatórios para entrega.');
    }

    const payload = {
        cliente_nome: nome,
        telefone: telefone || null,
        tipo_entrega: tipoEntrega,
        endereco: endereco || null,
        observacoes: observacoes || null,
        forma_pagamento: formaPagamento,
        troco_para: formaPagamento === 'dinheiro' ? Number(troco || 0) : 0,
        cupom_codigo: CUPOM_APLICADO ? CUPOM_APLICADO.codigo : null,
        itens: CARRINHO.map(item => {
            if (item.tipo_item === 'pizza') {
                return {
                    tipo_item: 'pizza',
                    pizza_categoria: item.pizza_categoria,
                    promocao_id: item.promocao_id || null,
                    fatias: item.fatias,
                    sabor_ids: item.sabor_ids,
                    borda_id: item.borda_id,
                    quantidade: item.quantidade
                };
            }
            return { tipo_item: item.tipo_item, produto_id: item.produto_id, quantidade: item.quantidade };
        })
    };

    try {
        const resultado = await apiFetch('/pedidos', { method: 'POST', body: JSON.stringify(payload) });
        document.getElementById('som-confirmacao').play().catch(() => {});
        mostrarTelaSucesso(resultado, formaPagamento, nome);
    } catch (err) {
        mostrarAvisoCarrinho(err.message);
    }
}

function mostrarTelaSucesso(resultado, formaPagamento, nome) {
    fecharCarrinho();

    document.getElementById('numero-pedido-sucesso').textContent = String(resultado.numeroPedidoDia).padStart(4, '0');
    document.getElementById('texto-sucesso').textContent =
        `Obrigado, ${nome}! Total: R$ ${Number(resultado.total).toFixed(2)}.`;

    const blocoWhatsapp = document.getElementById('bloco-whatsapp-pix');
    if (formaPagamento === 'pix' && CONFIG_LOJA.whatsapp_numero) {
        const mensagem = encodeURIComponent(
            `Olá! Segue o comprovante do Pix do meu pedido #${String(resultado.numeroPedidoDia).padStart(4, '0')} na Estação da Pizza.`
        );
        document.getElementById('btn-enviar-whatsapp').href =
            `https://wa.me/55${CONFIG_LOJA.whatsapp_numero.replace(/\D/g, '')}?text=${mensagem}`;
        blocoWhatsapp.classList.remove('oculto');
    } else {
        blocoWhatsapp.classList.add('oculto');
    }

    document.getElementById('sheet-fundo-sucesso').classList.remove('oculto');
}

function copiarChavePix() {
    const chave = CONFIG_LOJA.chave_pix;
    if (!chave) return alert('Chave Pix não configurada ainda. Fale com a pizzaria.');

    navigator.clipboard.writeText(chave).then(() => {
        const btn = document.getElementById('btn-copiar-pix');
        const textoOriginal = btn.innerHTML;
        btn.textContent = 'Chave copiada!';
        setTimeout(() => { btn.innerHTML = textoOriginal; }, 2000);
    }).catch(() => {
        alert(`Não foi possível copiar automaticamente. Chave Pix: ${chave}`);
    });
}

function mostrarAvisoCarrinho(msg) {
    const aviso = document.getElementById('aviso-carrinho');
    aviso.textContent = msg;
    aviso.classList.remove('oculto');
}

// ---------- Eventos gerais ----------
function configurarEventos() {
    document.getElementById('fechar-sheet-produto').addEventListener('click', fecharFichaProduto);
    document.getElementById('btn-add-carrinho').addEventListener('click', adicionarAoCarrinho);

    document.getElementById('qtd-menos').addEventListener('click', () => {
        const el = document.getElementById('qtd-valor');
        el.textContent = Math.max(1, Number(el.textContent) - 1);
    });
    document.getElementById('qtd-mais').addEventListener('click', () => {
        const el = document.getElementById('qtd-valor');
        el.textContent = Number(el.textContent) + 1;
    });

    document.getElementById('nav-carrinho').addEventListener('click', abrirCarrinho);
    document.getElementById('barra-carrinho').addEventListener('click', abrirCarrinho);
    document.getElementById('fechar-sheet-carrinho').addEventListener('click', fecharCarrinho);
    document.getElementById('btn-confirmar-pedido').addEventListener('click', confirmarPedido);
    document.getElementById('telefone').addEventListener('blur', buscarDadosClienteSalvos);
    document.getElementById('btn-aplicar-cupom').addEventListener('click', aplicarCupom);

    document.getElementById('btn-copiar-pix').addEventListener('click', copiarChavePix);
    document.getElementById('btn-fechar-sucesso').addEventListener('click', () => window.location.reload());

    document.getElementById('nav-inicio').addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

    document.getElementById('btn-busca').addEventListener('click', () => {
        document.getElementById('barra-busca').classList.toggle('oculto');
        document.getElementById('input-busca').focus();
    });
    document.getElementById('input-busca').addEventListener('input', filtrarBusca);

    document.querySelectorAll('.chip').forEach(chip => {
        chip.addEventListener('click', () => {
            document.querySelectorAll('.chip').forEach(c => c.classList.remove('ativo'));
            chip.classList.add('ativo');
            const secao = document.getElementById(`secao-${chip.dataset.cat}`);
            if (secao) secao.scrollIntoView({ behavior: 'smooth', block: 'start' });
        });
    });

    document.getElementById('nav-rastreio').addEventListener('click', abrirRastreioPedido);
    document.getElementById('fechar-sheet-rastreio').addEventListener('click', fecharRastreioPedido);
    document.getElementById('btn-rastrear-pedido').addEventListener('click', buscarPedidoRastreio);
    document.getElementById('btn-nova-busca-rastreio').addEventListener('click', reiniciarBuscaRastreio);
}

function filtrarBusca() {
    const termo = document.getElementById('input-busca').value.trim().toLowerCase();
    document.querySelectorAll('.linha-produto').forEach(linha => {
        const nome = linha.querySelector('.linha-produto-nome').textContent.toLowerCase();
        linha.style.display = nome.includes(termo) ? '' : 'none';
    });
}
function preencherRodape(config) {
    document.getElementById('rodape-ano').textContent = new Date().getFullYear();

    const horarioEl = document.getElementById('rodape-horario');
    horarioEl.textContent = `🕒 Funcionamos das ${config.horario_abertura?.slice(0,5)} às ${config.horario_fechamento?.slice(0,5)}`;

    const whatsappEl = document.getElementById('rodape-whatsapp');
    if (config.whatsapp_numero) {
        whatsappEl.href = `https://wa.me/55${config.whatsapp_numero.replace(/\D/g, '')}`;
        whatsappEl.classList.remove('oculto');
    }
}

// ---------- Acompanhar meu pedido ----------
let intervaloRastreioPedido = null;

const ETAPAS_STATUS = ['pendente', 'preparo', 'saiu_entrega', 'entregue'];

function abrirRastreioPedido() {
    document.getElementById('sheet-fundo-rastreio').classList.remove('oculto');
}

function fecharRastreioPedido() {
    document.getElementById('sheet-fundo-rastreio').classList.add('oculto');
    pararPollingRastreio();
}

function reiniciarBuscaRastreio() {
    pararPollingRastreio();
    document.getElementById('rastreio-resultado').classList.add('oculto');
    document.getElementById('rastreio-formulario').classList.remove('oculto');
    document.getElementById('rastreio-erro').classList.add('oculto');
}

function pararPollingRastreio() {
    if (intervaloRastreioPedido) {
        clearInterval(intervaloRastreioPedido);
        intervaloRastreioPedido = null;
    }
}

async function buscarPedidoRastreio() {
    const nome = document.getElementById('rastreio-nome').value.trim();
    const telefone = document.getElementById('rastreio-telefone').value.trim();
    const erroEl = document.getElementById('rastreio-erro');
    erroEl.classList.add('oculto');

    if (!nome || !telefone) {
        erroEl.textContent = 'Preencha o nome e o telefone usados no pedido.';
        erroEl.classList.remove('oculto');
        return;
    }

    const botao = document.getElementById('btn-rastrear-pedido');
    botao.disabled = true;
    botao.textContent = 'Buscando...';

    try {
        const pedido = await apiFetch(`/pedidos/rastrear?nome=${encodeURIComponent(nome)}&telefone=${encodeURIComponent(telefone)}`);
        exibirResultadoRastreio(pedido);
        iniciarPollingRastreio(pedido.id);
    } catch (err) {
        erroEl.textContent = err.message || 'Nenhum pedido encontrado com esse nome e telefone.';
        erroEl.classList.remove('oculto');
    } finally {
        botao.disabled = false;
        botao.textContent = 'Ver status';
    }
}

function exibirResultadoRastreio(pedido) {
    document.getElementById('rastreio-formulario').classList.add('oculto');
    document.getElementById('rastreio-resultado').classList.remove('oculto');
    document.getElementById('rastreio-numero').textContent = String(pedido.numero_pedido_dia).padStart(4, '0');

    // Os rótulos mudam um pouco pra quem vai retirar (não faz sentido dizer
    // "saiu para entrega" de um pedido que a pessoa vai buscar na loja).
    const paraRetirada = pedido.tipo_entrega === 'retirada';
    document.getElementById('rastreio-label-entrega').textContent = paraRetirada ? 'Pronto para retirar' : 'Saiu para entrega';
    document.getElementById('rastreio-label-final').textContent = paraRetirada ? 'Retirado' : 'Entregue';

    const itensEl = document.getElementById('rastreio-itens');
    itensEl.innerHTML = pedido.itens.map(item => {
        if (item.tipo_item === 'pizza') {
            const sabores = (item.sabores || []).join(', ');
            return `<p>${item.quantidade}x Pizza${item.nome_item ? ' ' + escapeHtml(item.nome_item) : ''} (${item.fatias} fatias) - ${escapeHtml(sabores)}</p>`;
        }
        return `<p>${item.quantidade}x ${escapeHtml(item.nome_item || '')}</p>`;
    }).join('');
    document.getElementById('rastreio-total').textContent = `Total: R$ ${Number(pedido.total).toFixed(2).replace('.', ',')}`;

    atualizarEtapaStatus(pedido.status);
}

function atualizarEtapaStatus(status) {
    const indiceAtual = ETAPAS_STATUS.indexOf(status);
    document.querySelectorAll('#linha-status .etapa-status').forEach(etapa => {
        const indiceEtapa = ETAPAS_STATUS.indexOf(etapa.dataset.status);
        etapa.classList.toggle('concluida', indiceEtapa < indiceAtual);
        etapa.classList.toggle('atual', indiceEtapa === indiceAtual);
    });
}

// Atualiza sozinho enquanto a ficha estiver aberta, sem precisar recarregar
// a página. Para automaticamente quando o pedido chega no status final.
function iniciarPollingRastreio(pedidoId) {
    pararPollingRastreio();
    intervaloRastreioPedido = setInterval(async () => {
        try {
            const { status } = await apiFetch(`/pedidos/${pedidoId}/status`);
            atualizarEtapaStatus(status);
            if (status === 'entregue') pararPollingRastreio();
        } catch (err) {
            // Se der erro numa atualização (rede instável, etc.), só tenta de
            // novo na próxima rodada - não vale a pena incomodar o cliente
            // com um erro por causa de uma consulta de atualização automática.
        }
    }, 20000);
}
